/*
 *	PROGRAM:	UDF and Blob filter Utilities library
 *	MODULE:		ib_util.h
 *	DESCRIPTION:	Prototype header file for ib_util.c
 *
 * copyright (c) 1998 by InterBase Software Corporation
 */

#ifndef _IB_UTIL_H
#define _IB_UTIL_H

extern void * 	ib_util_malloc (long);

#endif /* _IB_UTIL_H */
